-- Adminer 4.7.2 MySQL dump

SET NAMES utf8;
SET time_zone = '+00:00';
SET foreign_key_checks = 0;
SET sql_mode = 'NO_AUTO_VALUE_ON_ZERO';

DROP DATABASE IF EXISTS `rudi`;
CREATE DATABASE `rudi` /*!40100 DEFAULT CHARACTER SET utf8 */;
USE `rudi`;

DROP TABLE IF EXISTS `Links`;
CREATE TABLE `Links` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `link` varchar(255) CHARACTER SET utf8 NOT NULL,
  `link_text` varchar(255) CHARACTER SET utf8 NOT NULL,
  `country` varchar(255) NOT NULL,
  `description` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `Links` (`id`, `link`, `link_text`, `country`, `description`) VALUES
(1,	'https://www.google.de',	'google',	'USA',	'Google Search Engine'),
(2,	'https://www.publicplan.de',	'publicplan',	'Germany',	'Test Test');

-- 2019-11-10 14:38:31
